mui.init({swipeBack: false
,gestureConfig: {tap: true,doubletap: true,longtap: true}});

var 标题栏1 = new 标题栏("标题栏1",null,null,null);
var 面板1 = new 面板("面板1");
var CYS悬浮文字导航_大分类 = new CYS悬浮文字导航("CYS悬浮文字导航_大分类",CYS悬浮文字导航_大分类_项目被单击,null);
var CYS悬浮文字导航_小分类电视剧 = new CYS悬浮文字导航("CYS悬浮文字导航_小分类电视剧",CYS悬浮文字导航_小分类电视剧_项目被单击,null);
var CYS悬浮文字导航_小分类电影 = new CYS悬浮文字导航("CYS悬浮文字导航_小分类电影",CYS悬浮文字导航_小分类电影_项目被单击,null);
var CYS悬浮文字导航_小分类综艺 = new CYS悬浮文字导航("CYS悬浮文字导航_小分类综艺",CYS悬浮文字导航_小分类综艺_项目被单击,null);
var CYS悬浮文字导航_小分类动漫 = new CYS悬浮文字导航("CYS悬浮文字导航_小分类动漫",CYS悬浮文字导航_小分类动漫_项目被单击,null);
var CYS悬浮文字导航_年份电视剧 = new CYS悬浮文字导航("CYS悬浮文字导航_年份电视剧",CYS悬浮文字导航_年份电视剧_项目被单击,null);
var 网络操作_正则 = new 网络操作("网络操作_正则",网络操作_正则_发送完毕);
var 编辑框_正则 = new 编辑框("编辑框_正则",null,null,null,null,null);
var 网络操作_电影 = new 网络操作("网络操作_电影",网络操作_电影_发送完毕);
var 正则_电影 = new 正则("正则_电影");
var 网络操作_电视 = new 网络操作("网络操作_电视",网络操作_电视_发送完毕);
var 正则_电视 = new 正则("正则_电视");
var 网络操作_综艺 = new 网络操作("网络操作_综艺",网络操作_综艺_发送完毕);
var 正则_综艺 = new 正则("正则_综艺");
var 网络操作_动漫 = new 网络操作("网络操作_动漫",网络操作_动漫_发送完毕);
var 正则_动漫 = new 正则("正则_动漫");
var 网络操作_筛选电视剧 = new 网络操作("网络操作_筛选电视剧",null);
var 正则_分类 = new 正则("正则_分类");
var 对话框1 = new 对话框("对话框1",null,null,null);
var 面板_小分类电视 = new 面板("面板_小分类电视");
var 面板_小分类电影 = new 面板("面板_小分类电影");
var 面板_小分类综艺 = new 面板("面板_小分类综艺");
var 面板_小分类动漫 = new 面板("面板_小分类动漫");
var 面板_年份电视剧 = new 面板("面板_年份电视剧");
var 面板_年份电影 = new 面板("面板_年份电影");
var 面板_年份综艺 = new 面板("面板_年份综艺");
var 面板_年份动漫 = new 面板("面板_年份动漫");
var CYS悬浮文字导航_年份电影 = new CYS悬浮文字导航("CYS悬浮文字导航_年份电影",CYS悬浮文字导航_年份电影_项目被单击,null);
var CYS悬浮文字导航_年份综艺 = new CYS悬浮文字导航("CYS悬浮文字导航_年份综艺",CYS悬浮文字导航_年份综艺_项目被单击,null);
var CYS悬浮文字导航_年份动漫 = new CYS悬浮文字导航("CYS悬浮文字导航_年份动漫",CYS悬浮文字导航_年份动漫_项目被单击,null);
var CYS悬浮文字导航_地区电视剧 = new CYS悬浮文字导航("CYS悬浮文字导航_地区电视剧",CYS悬浮文字导航_地区电视剧_项目被单击,null);
var CYS悬浮文字导航_地区电影 = new CYS悬浮文字导航("CYS悬浮文字导航_地区电影",CYS悬浮文字导航_地区电影_项目被单击,null);
var CYS悬浮文字导航_地区综艺 = new CYS悬浮文字导航("CYS悬浮文字导航_地区综艺",CYS悬浮文字导航_地区综艺_项目被单击,null);
var CYS悬浮文字导航_地区动漫 = new CYS悬浮文字导航("CYS悬浮文字导航_地区动漫",CYS悬浮文字导航_地区动漫_项目被单击,null);
var 面板_地区电视剧 = new 面板("面板_地区电视剧");
var 面板_地区电影 = new 面板("面板_地区电影");
var 面板_地区综艺 = new 面板("面板_地区综艺");
var 面板_地区动漫 = new 面板("面板_地区动漫");
var 影视列表框1 = new 影视列表框("影视列表框1",影视列表框1_表项被单击,影视列表框1_表项被单击);
var 仔仔1 = new 仔仔("仔仔1",null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null);
var 按钮组1 = new 按钮组("按钮组1",按钮组1_被单击);
var 按钮组2 = new 按钮组("按钮组2",按钮组2_被单击);
var 按钮组3 = new 按钮组("按钮组3",按钮组3_被单击);
var 按钮组4 = new 按钮组("按钮组4",按钮组4_被单击);
var 仔仔弹出对话框1 = new 仔仔弹出对话框("仔仔弹出对话框1");
var 网络操作_会员时间 = new 网络操作("网络操作_会员时间",null);
var 网络操作_北京时间 = new 网络操作("网络操作_北京时间",null);
var 编辑框_北京时间 = new 编辑框("编辑框_北京时间",null,null,null,null,null);
var 图片框1 = new 图片框("图片框1",图片框1_被单击);
if(mui.os.plus){
    mui.plusReady(function() {
        分类视频_创建完毕();

    });
}else{
    window.onload=function(){
        分类视频_创建完毕();

    }
}
window.addEventListener("customEvent",function(event){分类视频_切换完毕(event.detail.param);});

	var 北京时间;
	var 到期时间;
	var 地址;
	var 视频标题;
	var 视频图片;
	var 直链地址;
	var 接口播放;
	var 大分类;
	var 小分类电视剧;
	var 小分类电影;
	var 小分类综艺;
	var 小分类动漫;

	var 年份电视剧;
	var 年份电影;
	var 年份综艺;
	var 年份动漫;

	var 地区电视剧;
	var 地区电影;
	var 地区综艺;
	var 地区动漫;

	var cat_电视剧="all";
	var year_电视剧="all";
	var area_电视剧="all";
	var act_电视剧="all";
	var 网页_电视剧= "http://www.360kan.com/dianshi/list?cat=";

	var cat_电影="all";
	var year_电影="all";
	var area_电影="all";
	var act_电影="all";
	var 网页_电影= "http://www.360kan.com/dianying/list?cat=";

	var cat_综艺="all";
	var year_综艺="all";
	var area_综艺="all";
	var act_综艺="all";
	var 网页_综艺= "http://www.360kan.com/zongyi/list?cat=";

	var cat_动漫="all";
	var year_动漫="all";
	var area_动漫="all";
	var act_动漫="all";
	var 网页_动漫= "http://www.360kan.com/dongman/list?cat=";

	var 电视剧页数= 1;
	var 电影页数= 1;
	var 综艺页数= 1;
	var 动漫页数= 1;

function 分类视频_创建完毕(){
	标题栏1.置右侧图标("mui-icon","mui-icon-search");
	document.getElementById("标题栏1").style.boxShadow = "#FFFFFF 0px 3px 6px";

	窗口操作.预加载窗口("./bofangye.html");
	var i大分类= 0;
	var i小分类= 0;
	var i小电影= 0;
	var i小综艺= 0;
	var i小动漫= 0;
	var i年份电视剧= 0;
	var i年份电影= 0;
	var i年份综艺= 0;
	var i年份动漫= 0;
	var i地区电视剧= 0;
	var i地区电影= 0;
	var i地区综艺= 0;
	var i地区动漫= 0;

	面板1.添加组件("CYS悬浮文字导航_大分类","92%");
	面板1.添加组件("图片框1","8%");
	面板1.置背景颜色("#FFFFFF");
	面板1.置外边距("0px","0px","0px","0px");
	窗口操作.置组件外边距("图片框1","11px","7px","0px","7px");
	图片框1.置图片("../image/fenlei/gengduo.png");

	按钮组1.置样式(0,"mui-btn");
	按钮组1.置标题(0,"共30页");
	按钮组1.置样式(2,"mui-btn mui-btn-outlined");
	按钮组1.置标题(2,"上一页");
	按钮组1.置样式(3,"mui-btn mui-btn-outlined");
	按钮组1.置标题(3,"下一页");

	按钮组2.置样式(0,"mui-btn");
	按钮组2.置标题(0,"共30页");
	按钮组2.置样式(1,"mui-btn");
	按钮组2.置样式(2,"mui-btn mui-btn-outlined");
	按钮组2.置标题(2,"上一页");
	按钮组2.置样式(3,"mui-btn mui-btn-outlined");
	按钮组2.置标题(3,"下一页");

	按钮组3.置样式(0,"mui-btn");
	按钮组3.置标题(0,"共30页");
	按钮组3.置样式(1,"mui-btn");
	按钮组3.置样式(2,"mui-btn mui-btn-outlined");
	按钮组3.置标题(2,"上一页");
	按钮组3.置样式(3,"mui-btn mui-btn-outlined");
	按钮组3.置标题(3,"下一页");

	按钮组4.置样式(0,"mui-btn");
	按钮组4.置标题(0,"共30页");
	按钮组4.置样式(1,"mui-btn");
	按钮组4.置样式(2,"mui-btn mui-btn-outlined");
	按钮组4.置标题(2,"上一页");
	按钮组4.置样式(3,"mui-btn mui-btn-outlined");
	按钮组4.置标题(3,"下一页");

	按钮组1.置可视(true);
	按钮组2.置可视(false);
	按钮组3.置可视(false);
	按钮组4.置可视(false);

	网络操作_正则.发送网络请求("../css/css/test.txt","get","txt","",5000);

	大分类 = 文本操作.分割文本("电视剧-电影-综艺-动漫","-");
	while(i大分类 < 数组操作.取成员数(大分类)){
	CYS悬浮文字导航_大分类.添加项目(大分类[i大分类],i大分类);
	CYS悬浮文字导航_大分类.置背景颜色("#FFFFFF");
	i大分类 = i大分类 + 1;
	}



	小分类电视剧 = 文本操作.分割文本("全部-言情-伦理-喜剧-悬疑-偶像-古装-军事-警匪-历史-武侠-科幻-宫廷-情景-动作-励志-神话-谍战-粤语-其他","-");
	while(i小分类 < 数组操作.取成员数(小分类电视剧)){
	CYS悬浮文字导航_小分类电视剧.添加项目(小分类电视剧[i小分类],i小分类);
	CYS悬浮文字导航_小分类电视剧.置背景颜色("#FFFFFF");
	i小分类 = i小分类 + 1;
	}

	小分类电影 = 文本操作.分割文本("全部-喜剧-爱情-动作-恐怖-科幻-剧情-犯罪-奇幻-战争-悬疑-动画-文艺-伦理-纪录-传记-歌舞-古装-历史-惊悚-其他","-");
	while(i小电影 < 数组操作.取成员数(小分类电影)){
	CYS悬浮文字导航_小分类电影.添加项目(小分类电影[i小电影],i小电影);
	CYS悬浮文字导航_小分类电影.置背景颜色("#FFFFFF");
	i小电影 = i小电影 + 1;
	}

	小分类综艺 = 文本操作.分割文本("全部-选秀-八卦-访谈-情感-生活-晚会-搞笑-音乐-时尚-游戏-少儿-体育-纪实-科教-曲艺-歌舞-财经-汽车-播报-其他-真人秀","-");
	while(i小综艺 < 数组操作.取成员数(小分类综艺)){
	CYS悬浮文字导航_小分类综艺.添加项目(小分类综艺[i小综艺],i小综艺);
	CYS悬浮文字导航_小分类综艺.置背景颜色("#FFFFFF");
	i小综艺 = i小综艺 + 1;
	}

	小分类动漫 = 文本操作.分割文本("全部-热血-恋爱-美少女-运动-校园-搞笑-幻想-冒险-悬疑-魔幻-动物-少儿-亲子-机战-怪物-益智-战争-社会-友情-成人-竞技-耽美-童话-LOLI-青春-男性向-女性向-动作-真人版-OVA版-TV版-电影版-新番动画-完结动画","-");
	while(i小动漫 < 数组操作.取成员数(小分类动漫)){
	CYS悬浮文字导航_小分类动漫.添加项目(小分类动漫[i小动漫],i小动漫);
	CYS悬浮文字导航_小分类动漫.置背景颜色("#FFFFFF");
	i小动漫 = i小动漫 + 1;
	}



	年份电视剧 = 文本操作.分割文本("全部-2018-2017-2016-2015-2014-2013-2012-2010-2009-2008-2007-更早","-");
	while(i年份电视剧 < 数组操作.取成员数(年份电视剧)){
	CYS悬浮文字导航_年份电视剧.添加项目(年份电视剧[i年份电视剧],i年份电视剧);
	CYS悬浮文字导航_年份电视剧.置背景颜色("#FFFFFF");
	i年份电视剧 = i年份电视剧 + 1;
	}

	年份电影 = 文本操作.分割文本("全部-2018-2017-2016-2015-2014-2013-2012-2010-2009-2008-2007-更早","-");
	while(i年份电影 < 数组操作.取成员数(年份电影)){
	CYS悬浮文字导航_年份电影.添加项目(年份电影[i年份电影],i年份电影);
	CYS悬浮文字导航_年份电影.置背景颜色("#FFFFFF");
	i年份电影 = i年份电影 + 1;
	}

	年份综艺 = 文本操作.分割文本("全部-徐熙娣-蔡康永-陈鲁豫-孟非-乐嘉-何炅-谢娜-罗志祥-陶晶莹-郭德纲-周立波-窦文涛-汪涵-陈建州-王刚-朱丹","-");
	while(i年份综艺 < 数组操作.取成员数(年份综艺)){
	CYS悬浮文字导航_年份综艺.添加项目(年份综艺[i年份综艺],i年份综艺);
	CYS悬浮文字导航_年份综艺.置背景颜色("#FFFFFF");
	i年份综艺 = i年份综艺 + 1;
	}

	年份动漫 = 文本操作.分割文本("全部-2018-2017-2016-2015-2014-2013-2012-2010-2009-2008-2007-2006-2005-2004-更早","-");
	while(i年份动漫 < 数组操作.取成员数(年份动漫)){
	CYS悬浮文字导航_年份动漫.添加项目(年份动漫[i年份动漫],i年份动漫);
	CYS悬浮文字导航_年份动漫.置背景颜色("#FFFFFF");
	i年份动漫 = i年份动漫 + 1;
	}



	地区电视剧 = 文本操作.分割文本("全部-内地-香港-台湾-韩国-泰国-日本-美国-英国-新加坡","-");
	while(i地区电视剧 < 数组操作.取成员数(地区电视剧)){
	CYS悬浮文字导航_地区电视剧.添加项目(地区电视剧[i地区电视剧],i地区电视剧);
	CYS悬浮文字导航_地区电视剧.置背景颜色("#FFFFFF");
	i地区电视剧 = i地区电视剧 + 1;
	}

	地区电影 = 文本操作.分割文本("全部-美国-大陆-香港-韩国-日本-法国-英国-德国-台湾-泰国-印度-其他","-");
	while(i地区电影 < 数组操作.取成员数(地区电影)){
	CYS悬浮文字导航_地区电影.添加项目(地区电影[i地区电影],i地区电影);
	CYS悬浮文字导航_地区电影.置背景颜色("#FFFFFF");
	i地区电影 = i地区电影 + 1;
	}

	地区综艺 = 文本操作.分割文本("全部-大陆-台湾-韩国-日本-欧美-香港","-");
	while(i地区综艺 < 数组操作.取成员数(地区综艺)){
	CYS悬浮文字导航_地区综艺.添加项目(地区综艺[i地区综艺],i地区综艺);
	CYS悬浮文字导航_地区综艺.置背景颜色("#FFFFFF");
	i地区综艺 = i地区综艺 + 1;

	}
	地区动漫 = 文本操作.分割文本("全部-日本-美国-大陆","-");
	while(i地区动漫 < 数组操作.取成员数(地区动漫)){
	CYS悬浮文字导航_地区动漫.添加项目(地区动漫[i地区动漫],i地区动漫);
	CYS悬浮文字导航_地区动漫.置背景颜色("#FFFFFF");
	i地区动漫 = i地区动漫 + 1;
	}



	面板_小分类电视.添加组件("CYS悬浮文字导航_小分类电视剧","100%");
	面板_小分类电影.添加组件("CYS悬浮文字导航_小分类电影","100%");
	面板_小分类综艺.添加组件("CYS悬浮文字导航_小分类综艺","100%");
	面板_小分类动漫.添加组件("CYS悬浮文字导航_小分类动漫","100%");

	面板_年份电视剧.添加组件("CYS悬浮文字导航_年份电视剧","100%");
	面板_年份电影.添加组件("CYS悬浮文字导航_年份电影","100%");
	面板_年份综艺.添加组件("CYS悬浮文字导航_年份综艺","100%");
	面板_年份动漫.添加组件("CYS悬浮文字导航_年份动漫","100%");

	面板_地区电视剧.添加组件("CYS悬浮文字导航_地区电视剧","100%");
	面板_地区电影.添加组件("CYS悬浮文字导航_地区电影","100%");
	面板_地区综艺.添加组件("CYS悬浮文字导航_地区综艺","100%");
	面板_地区动漫.添加组件("CYS悬浮文字导航_地区动漫","100%");

	面板_小分类电视.置可视(false);
	面板_小分类电影.置可视(false);
	面板_小分类综艺.置可视(false);
	面板_小分类动漫.置可视(false);

	面板_年份电视剧.置可视(false);
	面板_年份电影.置可视(false);
	面板_年份综艺.置可视(false);
	面板_年份动漫.置可视(false);

	面板_地区电视剧.置可视(false);
	面板_地区电影.置可视(false);
	面板_地区综艺.置可视(false);
	面板_地区动漫.置可视(false);

	面板_小分类电视.置外边距("0px","0px","0px","0px");
	面板_小分类电影.置外边距("0px","0px","0px","0px");
	面板_小分类综艺.置外边距("0px","0px","0px","0px");
	面板_小分类动漫.置外边距("0px","0px","0px","0px");

	面板_年份电视剧.置外边距("0px","0px","0px","0px");
	面板_年份电影.置外边距("0px","0px","0px","0px");
	面板_年份综艺.置外边距("0px","0px","0px","0px");
	面板_年份动漫.置外边距("0px","0px","0px","0px");

	面板_地区电视剧.置外边距("0px","0px","0px","0px");
	面板_地区电影.置外边距("0px","0px","0px","0px");
	面板_地区综艺.置外边距("0px","0px","0px","0px");
	面板_地区动漫.置外边距("0px","0px","0px","0px");

	CYS悬浮文字导航_大分类.置分割线颜色("#FFFFFF");
	CYS悬浮文字导航_大分类.置默认文本颜色("#000000");
	CYS悬浮文字导航_大分类.置选中认文本颜色("#000000");

}

function 网络操作_正则_发送完毕(发送结果,返回信息){
	编辑框_正则.置内容(返回信息);
	网络操作_电视.发送网络请求("https://www.360kan.com/dianshi/list","get","html","",5000);
}

function 网络操作_电视_发送完毕(发送结果,返回信息){
	var 图片;
	var 标题;
	var 更新;
	var 介绍;
	var 地址;
	var 评分;
	var 评分背景图;
	var VIP背景图;
	var 十九电视= 0;

		按钮组1.置标题(1,"第" + 电视剧页数 + "页");
		对话框1.关闭等待框();
		影视列表框1.清空项目();
		正则_电视.创建正则(返回信息,编辑框_正则.取内容());

		while(十九电视 < 正则_电视.取匹配数量()){

		地址 = "http://www.360kan.com" + 正则_电视.取子匹配文本(十九电视,1);
		图片 = 正则_电视.取子匹配文本(十九电视,3);
		更新 = 正则_电视.取子匹配文本(十九电视,5);
		标题 = 正则_电视.取子匹配文本(十九电视,7);
		评分 = 正则_电视.取子匹配文本(十九电视,9);
		介绍 = 正则_电视.取子匹配文本(十九电视,11);


		VIP背景图 = "../image/fenlei/vip_2.png";
		影视列表框1.添加项目(图片,标题,更新,介绍,地址,评分,评分背景图,VIP背景图);
		十九电视 ++;

		}


	读写设置.保存设置("播放分类","电视");
}

function 网络操作_电影_发送完毕(发送结果,返回信息){
	var 图片;
	var 标题;
	var 更新;
	var 介绍;
	var 地址;
	var 评分;
	var 评分背景图;
	var VIP背景图;
	var 十九电影= 0;
		按钮组2.置标题(1,"第" + 电影页数 + "页");
		对话框1.关闭等待框();
		影视列表框1.清空项目();
	正则_电影.创建正则(返回信息,编辑框_正则.取内容());
	while(十九电影 != 正则_电影.取匹配数量()){

		地址 = "http://www.360kan.com" + 正则_电影.取子匹配文本(十九电影,1);
		图片 = 正则_电影.取子匹配文本(十九电影,3);
		更新 = 正则_电影.取子匹配文本(十九电影,5);
		标题 = 正则_电影.取子匹配文本(十九电影,7);
		评分 = 正则_电影.取子匹配文本(十九电影,9);
		介绍 = 正则_电影.取子匹配文本(十九电影,11);

		VIP背景图 = "../image/fenlei/vip_2.png";
		影视列表框1.添加项目(图片,标题,更新,介绍,地址,评分,评分背景图,VIP背景图);
		十九电影 ++;

	}
	读写设置.保存设置("播放分类","电影");
}

function 网络操作_综艺_发送完毕(发送结果,返回信息){
	var 图片;
	var 标题;
	var 更新;
	var 介绍;
	var 地址;
	var 评分;
	var 评分背景图;
	var VIP背景图;
	var 十九综艺= 0;

		按钮组3.置标题(1,"第" + 综艺页数 + "页");
		对话框1.关闭等待框();
		影视列表框1.清空项目();

	正则_综艺.创建正则(返回信息,编辑框_正则.取内容());
	while(十九综艺 != 正则_综艺.取匹配数量()){

		地址 = "http://www.360kan.com" + 正则_综艺.取子匹配文本(十九综艺,1);
		图片 = 正则_综艺.取子匹配文本(十九综艺,3);
		更新 = 正则_综艺.取子匹配文本(十九综艺,5);
		标题 = 正则_综艺.取子匹配文本(十九综艺,7);
		评分 = 正则_综艺.取子匹配文本(十九综艺,9);
		介绍 = 正则_综艺.取子匹配文本(十九综艺,11);

		VIP背景图 = "../image/fenlei/vip_2.png";

		影视列表框1.添加项目(图片,标题,更新,介绍,地址,评分,评分背景图,VIP背景图);
		十九综艺 ++;


	}
	读写设置.保存设置("播放分类","综艺");
}

function 网络操作_动漫_发送完毕(发送结果,返回信息){
	var 图片;
	var 标题;
	var 更新;
	var 介绍;
	var 地址;
	var 评分;
	var 评分背景图;
	var VIP背景图;
	var 十九动漫= 0;

		按钮组4.置标题(1,"第" + 动漫页数 + "页");
		对话框1.关闭等待框();
		影视列表框1.清空项目();

	正则_动漫.创建正则(返回信息,编辑框_正则.取内容());
	while(十九动漫 != 正则_动漫.取匹配数量()){

		地址 = "http://www.360kan.com" + 正则_动漫.取子匹配文本(十九动漫,1);
		图片 = 正则_动漫.取子匹配文本(十九动漫,3);
		更新 = 正则_动漫.取子匹配文本(十九动漫,5);
		标题 = 正则_动漫.取子匹配文本(十九动漫,7);
		评分 = 正则_动漫.取子匹配文本(十九动漫,9);
		介绍 = 正则_动漫.取子匹配文本(十九动漫,11);

		VIP背景图 = "../image/fenlei/vip_2.png";
		影视列表框1.添加项目(图片,标题,更新,介绍,地址,评分,评分背景图,VIP背景图);
		十九动漫 ++;


	}
	读写设置.保存设置("播放分类","动漫");
}

function 影视列表框1_表项被单击(id,标题,图片,标记){
	var 分割;
	var 账号密码= 读写设置.读取设置("vip");
	if (文本操作.寻找文本(账号密码,"----",0) != -1){
		分割 = 文本操作.分割文本(账号密码,"----");
		}else {
      读写设置.保存设置("播放标题",标题);
      读写设置.保存设置("播放图片",图片);
      读写设置.保存设置("播放地址",标记);
      api.openWin({
          name: 'h5',
          url: '../html/bofangye.html',
          pageParam:{title:读写设置.保存设置("播放标题",标题)}
      });
		return;
	}
	if (分割[0] != null && 分割[0] != "" && 分割[1] != null && 分割[1] != "" && 读写设置.读取设置("loginstate") != "" && 读写设置.读取设置("loginstate") != null){
		if(数学操作.取整数(读写设置.读取设置("daoqishijian")) < 数学操作.取整数(仔仔1.时间_当前时间戳())){
			对话框1.信息框("温馨提示","您的VIP账户已到期");
			}else {
				读写设置.保存设置("播放标题",标题);
				读写设置.保存设置("播放图片",图片);
				读写设置.保存设置("播放地址",标记);
        api.openWin({
            name: 'h5',
            url: '../html/bofangye.html',
        });
			}
				}else {
          读写设置.保存设置("播放标题",标题);
  				读写设置.保存设置("播放图片",图片);
  				读写设置.保存设置("播放地址",标记);
          api.openWin({
              name: 'h5',
              url: '../html/bofangye.html',
          });
	}
}

function CYS悬浮文字导航_大分类_项目被单击(项目索引){
	读写设置.保存设置("判断展开","已展开");
	switch(项目索引){
		case 0 :
							面板_小分类电视.置可视(true);
							面板_小分类电影.置可视(false);
							面板_小分类综艺.置可视(false);
							面板_小分类动漫.置可视(false);

							面板_年份电视剧.置可视(true);
							面板_年份电影.置可视(false);
							面板_年份综艺.置可视(false);
							面板_年份动漫.置可视(false);

							面板_地区电视剧.置可视(true);
							面板_地区电影.置可视(false);
							面板_地区综艺.置可视(false);
							面板_地区动漫.置可视(false);

							按钮组1.置可视(true);
							按钮组2.置可视(false);
							按钮组3.置可视(false);
							按钮组4.置可视(false);


							读写设置.保存设置("播放分类","电视");
							网络操作_电视.发送网络请求("https://www.360kan.com/dianshi/list","get","txt","",5000);


		break;
		case 1 :
							面板_小分类电视.置可视(false);
							面板_小分类电影.置可视(true);
							面板_小分类综艺.置可视(false);
							面板_小分类动漫.置可视(false);

							面板_年份电视剧.置可视(false);
							面板_年份电影.置可视(true);
							面板_年份综艺.置可视(false);
							面板_年份动漫.置可视(false);

							面板_地区电视剧.置可视(false);
							面板_地区电影.置可视(true);
							面板_地区综艺.置可视(false);
							面板_地区动漫.置可视(false);

							按钮组1.置可视(false);
							按钮组2.置可视(true);
							按钮组3.置可视(false);
							按钮组4.置可视(false);


							读写设置.保存设置("播放分类","电影");
							网络操作_电影.发送网络请求("https://www.360kan.com/dianying/list","get","txt","",5000);

		break;
		case 2 :
							面板_小分类电视.置可视(false);
							面板_小分类电影.置可视(false);
							面板_小分类综艺.置可视(true);
							面板_小分类动漫.置可视(false);

							面板_年份电视剧.置可视(false);
							面板_年份电影.置可视(false);
							面板_年份综艺.置可视(true);
							面板_年份动漫.置可视(false);

							面板_地区电视剧.置可视(false);
							面板_地区电影.置可视(false);
							面板_地区综艺.置可视(true);
							面板_地区动漫.置可视(false);

							按钮组1.置可视(false);
							按钮组2.置可视(false);
							按钮组3.置可视(true);
							按钮组4.置可视(false);


							读写设置.保存设置("播放分类","综艺");
							网络操作_综艺.发送网络请求("https://www.360kan.com/zongyi/list","get","txt","",5000);

		break;
		case 3 :
							面板_小分类电视.置可视(false);
							面板_小分类电影.置可视(false);
							面板_小分类综艺.置可视(false);
							面板_小分类动漫.置可视(true);

							面板_年份电视剧.置可视(false);
							面板_年份电影.置可视(false);
							面板_年份综艺.置可视(false);
							面板_年份动漫.置可视(true);

							面板_地区电视剧.置可视(false);
							面板_地区电影.置可视(false);
							面板_地区综艺.置可视(false);
							面板_地区动漫.置可视(true);

							按钮组1.置可视(false);
							按钮组2.置可视(false);
							按钮组3.置可视(false);
							按钮组4.置可视(true);


							读写设置.保存设置("播放分类","动漫");
							网络操作_动漫.发送网络请求("https://www.360kan.com/dongman/list","get","txt","",5000);

		break;
	}
}

function CYS悬浮文字导航_小分类电视剧_项目被单击(项目索引){
	标题栏1.置标题("电视剧");
	读写设置.保存设置("播放分类","电视");
	switch(项目索引){
		case 0 :
			网络操作_电视.发送网络请求("https://www.360kan.com/dianshi/list","get","txt","",5000);
			cat_电视剧 = "all";
		break;
		case 1 :
			网络操作_电视.发送网络请求("https://www.360kan.com/dianshi/list?year=all&area=all&act=all&cat=101","get","txt","",5000);
			cat_电视剧 = "101";
		break;
		case 2 :
			网络操作_电视.发送网络请求("https://www.360kan.com/dianshi/list?year=all&area=all&act=all&cat=105","get","txt","",5000);
			cat_电视剧 = "105";
		break;
		case 3 :
			网络操作_电视.发送网络请求("https://www.360kan.com/dianshi/list?year=all&area=all&act=all&cat=109","get","txt","",5000);
			cat_电视剧 = "109";
		break;
		case 4 :
			网络操作_电视.发送网络请求("https://www.360kan.com/dianshi/list?year=all&area=all&act=all&cat=108","get","txt","",5000);
			cat_电视剧 = "108";
		break;
		case 5 :
			网络操作_电视.发送网络请求("https://www.360kan.com/dianshi/list?year=all&area=all&act=all&cat=111","get","txt","",5000);
			cat_电视剧 = "111";
		break;
		case 6 :
			网络操作_电视.发送网络请求("https://www.360kan.com/dianshi/list?year=all&area=all&act=all&cat=100","get","txt","",5000);
			cat_电视剧 = "100";
		break;
		case 7 :
			网络操作_电视.发送网络请求("https://www.360kan.com/dianshi/list?year=all&area=all&act=all&cat=104","get","txt","",5000);
			cat_电视剧 = "104";
		break;
		case 8 :
			网络操作_电视.发送网络请求("https://www.360kan.com/dianshi/list?year=all&area=all&act=all&cat=107","get","txt","",5000);
			cat_电视剧 = "107";
		break;
		case 9 :
			网络操作_电视.发送网络请求("https://www.360kan.com/dianshi/list?year=all&area=all&act=all&cat=103","get","txt","",5000);
			cat_电视剧 = "103";
		break;
		case 10 :
			网络操作_电视.发送网络请求("https://www.360kan.com/dianshi/list?year=all&area=all&act=all&cat=112","get","txt","",5000);
			cat_电视剧 = "112";
		break;
		case 11 :
			网络操作_电视.发送网络请求("https://www.360kan.com/dianshi/list?year=all&area=all&act=all&cat=106","get","txt","",5000);
			cat_电视剧 = "106";
		break;
		case 12 :
			网络操作_电视.发送网络请求("https://www.360kan.com/dianshi/list?year=all&area=all&act=all&cat=113","get","txt","",5000);
			cat_电视剧 = "113";
		break;
		case 13 :
			网络操作_电视.发送网络请求("https://www.360kan.com/dianshi/list?year=all&area=all&act=all&cat=102","get","txt","",5000);
			cat_电视剧 = "102";
		break;
		case 14 :
			网络操作_电视.发送网络请求("https://www.360kan.com/dianshi/list?year=all&area=all&act=all&cat=114","get","txt","",5000);
			cat_电视剧 = "114";
		break;
		case 15 :
			网络操作_电视.发送网络请求("https://www.360kan.com/dianshi/list?year=all&area=all&act=all&cat=115","get","txt","",5000);
			cat_电视剧 = "115";
		break;
		case 16 :
			网络操作_电视.发送网络请求("https://www.360kan.com/dianshi/list?year=all&area=all&act=all&cat=116","get","txt","",5000);
			cat_电视剧 = "116";
		break;
		case 17 :
			网络操作_电视.发送网络请求("https://www.360kan.com/dianshi/list?year=all&area=all&act=all&cat=117","get","txt","",5000);
			cat_电视剧 = "117";
		break;
		case 18 :
			网络操作_电视.发送网络请求("https://www.360kan.com/dianshi/list?year=all&area=all&act=all&cat=118","get","txt","",5000);
			cat_电视剧 = "118";
		break;
		case 19 :
			网络操作_电视.发送网络请求("https://www.360kan.com/dianshi/list?year=all&area=all&act=all&cat=110","get","txt","",5000);
			cat_电视剧 = "110";
		break;
		case 20 :
			网络操作_电视.发送网络请求("https://www.360kan.com/dianshi/list?year=all&area=all&act=all&cat=other","get","txt","",5000);
			cat_电视剧 = "other";
		break;
	}
}

function CYS悬浮文字导航_小分类电影_项目被单击(项目索引){
	标题栏1.置标题("电影");
	读写设置.保存设置("播放分类","电影");
	switch(项目索引){
		case 0 :
			网络操作_电影.发送网络请求("https://www.360kan.com/dianying/list","get","txt","",5000);
			cat_电影 = "all";
		break;
		case 1 :
			网络操作_电影.发送网络请求("https://www.360kan.com/dianying/list?year=all&area=all&act=all&cat=103","get","txt","",5000);
			cat_电影 = "103";
		break;
		case 2 :
			网络操作_电影.发送网络请求("https://www.360kan.com/dianying/list?year=all&area=all&act=all&cat=100","get","txt","",5000);
			cat_电影 = "100";
		break;
		case 3 :
			网络操作_电影.发送网络请求("https://www.360kan.com/dianying/list?year=all&area=all&act=all&cat=106","get","txt","",5000);
			cat_电影 = "106";
		break;
		case 4 :
			网络操作_电影.发送网络请求("https://www.360kan.com/dianying/list?year=all&area=all&act=all&cat=102","get","txt","",5000);
			cat_电影 = "102";
		break;
		case 5 :
			网络操作_电影.发送网络请求("https://www.360kan.com/dianying/list?year=all&area=all&act=all&cat=104","get","txt","",5000);
			cat_电影 = "104";
		break;
		case 6 :
			网络操作_电影.发送网络请求("https://www.360kan.com/dianying/list?year=all&area=all&act=all&cat=112","get","txt","",5000);
			cat_电影 = "112";
		break;
		case 7 :
			网络操作_电影.发送网络请求("https://www.360kan.com/dianying/list?year=all&area=all&act=all&cat=105","get","txt","",5000);
			cat_电影 = "105";
		break;
		case 8 :
			网络操作_电影.发送网络请求("https://www.360kan.com/dianying/list?year=all&area=all&act=all&cat=113","get","txt","",5000);
			cat_电影 = "113";
		break;
		case 9 :
			网络操作_电影.发送网络请求("https://www.360kan.com/dianying/list?year=all&area=all&act=all&cat=108","get","txt","",5000);
			cat_电影 = "108";
		break;
		case 10 :
			网络操作_电影.发送网络请求("https://www.360kan.com/dianying/list?year=all&area=all&act=all&cat=115","get","txt","",5000);
			cat_电影 = "115";
		break;
		case 11 :
			网络操作_电影.发送网络请求("https://www.360kan.com/dianying/list?year=all&area=all&act=all&cat=107","get","txt","",5000);
			cat_电影 = "107";
		break;
		case 12 :
			网络操作_电影.发送网络请求("https://www.360kan.com/dianying/list?year=all&area=all&act=all&cat=117","get","txt","",5000);
			cat_电影 = "117";
		break;
		case 13 :
			网络操作_电影.发送网络请求("https://www.360kan.com/dianying/list?year=all&area=all&act=all&cat=101","get","txt","",5000);
			cat_电影 = "101";
		break;
		case 14 :
			网络操作_电影.发送网络请求("https://www.360kan.com/dianying/list?year=all&area=all&act=all&cat=118","get","txt","",5000);
			cat_电影 = "118";
		break;
		case 15 :
			网络操作_电影.发送网络请求("https://www.360kan.com/dianying/list?year=all&area=all&act=all&cat=119","get","txt","",5000);
			cat_电影 = "119";
		break;
		case 16 :
			网络操作_电影.发送网络请求("https://www.360kan.com/dianying/list?year=all&area=all&act=all&cat=120","get","txt","",5000);
			cat_电影 = "120";
		break;
		case 17 :
			网络操作_电影.发送网络请求("https://www.360kan.com/dianying/list?year=all&area=all&act=all&cat=121","get","txt","",5000);
			cat_电影 = "121";
		break;
		case 18 :
			网络操作_电影.发送网络请求("https://www.360kan.com/dianying/list?year=all&area=all&act=all&cat=122","get","txt","",5000);
			cat_电影 = "122";
		break;
		case 19 :
			网络操作_电影.发送网络请求("https://www.360kan.com/dianying/list?year=all&area=all&act=all&cat=123","get","txt","",5000);
			cat_电影 = "123";
		break;
		case 20 :
			网络操作_电影.发送网络请求("https://www.360kan.com/dianying/list?year=all&area=all&act=all&cat=other","get","txt","",5000);
			cat_电影 = "other";
		break;
	}
}

function CYS悬浮文字导航_小分类综艺_项目被单击(项目索引){
	标题栏1.置标题("综艺");
	读写设置.保存设置("播放分类","综艺");
	switch(项目索引){
		case 0 :
			网络操作_综艺.发送网络请求("https://www.360kan.com/zongyi/list","get","txt","",5000);
			cat_综艺 = "all";
		break;
		case 1 :
			网络操作_综艺.发送网络请求("https://www.360kan.com/zongyi/list?act=all&area=all&cat=101","get","txt","",5000);
			cat_综艺 = "101";
		break;
		case 2 :
			网络操作_综艺.发送网络请求("https://www.360kan.com/zongyi/list?act=all&area=all&cat=102","get","txt","",5000);
			cat_综艺 = "102";
		break;
		case 3 :
			网络操作_综艺.发送网络请求("https://www.360kan.com/zongyi/list?act=all&area=all&cat=103","get","txt","",5000);
			cat_综艺 = "103";
		break;
		case 4 :
			网络操作_综艺.发送网络请求("https://www.360kan.com/zongyi/list?act=all&area=all&cat=104","get","txt","",5000);
			cat_综艺 = "104";
		break;
		case 5 :
			网络操作_综艺.发送网络请求("https://www.360kan.com/zongyi/list?act=all&area=all&cat=105","get","txt","",5000);
			cat_综艺 = "105";
		break;
		case 6 :
			网络操作_综艺.发送网络请求("https://www.360kan.com/zongyi/list?act=all&area=all&cat=106","get","txt","",5000);
			cat_综艺 = "106";
		break;
		case 7 :
			网络操作_综艺.发送网络请求("https://www.360kan.com/zongyi/list?act=all&area=all&cat=107","get","txt","",5000);
			cat_综艺 = "107";
		break;
		case 8 :
			网络操作_综艺.发送网络请求("https://www.360kan.com/zongyi/list?act=all&area=all&cat=108","get","txt","",5000);
			cat_综艺 = "108";
		break;
		case 9 :
			网络操作_综艺.发送网络请求("https://www.360kan.com/zongyi/list?act=all&area=all&cat=109","get","txt","",5000);
			cat_综艺 = "109";
		break;
		case 10 :
			网络操作_综艺.发送网络请求("https://www.360kan.com/zongyi/list?act=all&area=all&cat=110","get","txt","",5000);
			cat_综艺 = "110";
		break;
		case 11 :
			网络操作_综艺.发送网络请求("https://www.360kan.com/zongyi/list?act=all&area=all&cat=111","get","txt","",5000);
			cat_综艺 = "111";
		break;
		case 12 :
			网络操作_综艺.发送网络请求("https://www.360kan.com/zongyi/list?act=all&area=all&cat=112","get","txt","",5000);
			cat_综艺 = "112";
		break;
		case 13 :
			网络操作_综艺.发送网络请求("https://www.360kan.com/zongyi/list?act=all&area=all&cat=113","get","txt","",5000);
			cat_综艺 = "113";
		break;
		case 14 :
			网络操作_综艺.发送网络请求("https://www.360kan.com/zongyi/list?act=all&area=all&cat=114","get","txt","",5000);
			cat_综艺 = "114";
		break;
		case 15 :
			网络操作_综艺.发送网络请求("https://www.360kan.com/zongyi/list?act=all&area=all&cat=115","get","txt","",5000);
			cat_综艺 = "115";
		break;
		case 16 :
			网络操作_综艺.发送网络请求("https://www.360kan.com/zongyi/list?act=all&area=all&cat=116","get","txt","",5000);
			cat_综艺 = "116";
		break;
		case 17 :
			网络操作_综艺.发送网络请求("https://www.360kan.com/zongyi/list?act=all&area=all&cat=117","get","txt","",5000);
			cat_综艺 = "117";
		break;
		case 18 :
			网络操作_综艺.发送网络请求("https://www.360kan.com/zongyi/list?act=all&area=all&cat=118","get","txt","",5000);
			cat_综艺 = "118";
		break;
		case 19 :
			网络操作_综艺.发送网络请求("https://www.360kan.com/zongyi/list?act=all&area=all&cat=119","get","txt","",5000);
			cat_综艺 = "119";
		break;
		case 20 :
			网络操作_综艺.发送网络请求("https://www.360kan.com/zongyi/list?act=all&area=all&cat=other","get","txt","",5000);
			cat_综艺 = "other";
		break;
		case 21 :
			网络操作_综艺.发送网络请求("https://www.360kan.com/zongyi/list?act=all&area=all&cat=120","get","txt","",5000);
			cat_综艺 = "120";
		break;
	}
}

function CYS悬浮文字导航_小分类动漫_项目被单击(项目索引){
	标题栏1.置标题("动漫");
	读写设置.保存设置("播放分类","动漫");
	switch(项目索引){
		case 0 :
			网络操作_动漫.发送网络请求("https://www.360kan.com/dongman/list?year=all&area=all&cat=all","get","txt","",5000);
			cat_动漫 = "all";
		break;
		case 1 :
			网络操作_动漫.发送网络请求("https://www.360kan.com/dongman/list?year=all&area=all&cat=100","get","txt","",5000);
			cat_动漫 = "100";
		break;
		case 2 :
			网络操作_动漫.发送网络请求("https://www.360kan.com/dongman/list?year=all&area=all&cat=101","get","txt","",5000);
			cat_动漫 = "101";
		break;
		case 3 :
			网络操作_动漫.发送网络请求("https://www.360kan.com/dongman/list?year=all&area=all&cat=102","get","txt","",5000);
			cat_动漫 = "102";
		break;
		case 4 :
			网络操作_动漫.发送网络请求("https://www.360kan.com/dongman/list?year=all&area=all&cat=103","get","txt","",5000);
			cat_动漫 = "103";
		break;
		case 5 :
			网络操作_动漫.发送网络请求("https://www.360kan.com/dongman/list?year=all&area=all&cat=104","get","txt","",5000);
			cat_动漫 = "104";
		break;
		case 6 :
			网络操作_动漫.发送网络请求("https://www.360kan.com/dongman/list?year=all&area=all&cat=105","get","txt","",5000);
			cat_动漫 = "105";
		break;
		case 7 :
			网络操作_动漫.发送网络请求("https://www.360kan.com/dongman/list?year=all&area=all&cat=106","get","txt","",5000);
			cat_动漫 = "106";
		break;
		case 8 :
			网络操作_动漫.发送网络请求("https://www.360kan.com/dongman/list?year=all&area=all&cat=107","get","txt","",5000);
			cat_动漫 = "107";
		break;
		case 9 :
			网络操作_动漫.发送网络请求("https://www.360kan.com/dongman/list?year=all&area=all&cat=108","get","txt","",5000);
			cat_动漫 = "108";
		break;
		case 10 :
			网络操作_动漫.发送网络请求("https://www.360kan.com/dongman/list?year=all&area=all&cat=109","get","txt","",5000);
			cat_动漫 = "109";
		break;
		case 11 :
			网络操作_动漫.发送网络请求("https://www.360kan.com/dongman/list?year=all&area=all&cat=110","get","txt","",5000);
			cat_动漫 = "110";
		break;
		case 12 :
			网络操作_动漫.发送网络请求("https://www.360kan.com/dongman/list?year=all&area=all&cat=111","get","txt","",5000);
			cat_动漫 = "111";
		break;
		case 13 :
			网络操作_动漫.发送网络请求("https://www.360kan.com/dongman/list?year=all&area=all&cat=131","get","txt","",5000);
			cat_动漫 = "131";
		break;
		case 14 :
			网络操作_动漫.发送网络请求("https://www.360kan.com/dongman/list?year=all&area=all&cat=112","get","txt","",5000);
			cat_动漫 = "112";
		break;
		case 15 :
			网络操作_动漫.发送网络请求("https://www.360kan.com/dongman/list?year=all&area=all&cat=113","get","txt","",5000);
			cat_动漫 = "113";
		break;
		case 16 :
			网络操作_动漫.发送网络请求("https://www.360kan.com/dongman/list?year=all&area=all&cat=114","get","txt","",5000);
			cat_动漫 = "114";
		break;
		case 17 :
			网络操作_动漫.发送网络请求("https://www.360kan.com/dongman/list?year=all&area=all&cat=115","get","txt","",5000);
			cat_动漫 = "115";
		break;
		case 18 :
			网络操作_动漫.发送网络请求("https://www.360kan.com/dongman/list?year=all&area=all&cat=116","get","txt","",5000);
			cat_动漫 = "116";
		break;
		case 19 :
			网络操作_动漫.发送网络请求("https://www.360kan.com/dongman/list?year=all&area=all&cat=117","get","txt","",5000);
			cat_动漫 = "117";
		break;
		case 20 :
			网络操作_动漫.发送网络请求("https://www.360kan.com/dongman/list?year=all&area=all&cat=118","get","txt","",5000);
			cat_动漫 = "118";
		break;
		case 21 :
			网络操作_动漫.发送网络请求("https://www.360kan.com/dongman/list?year=all&area=all&cat=119","get","txt","",5000);
			cat_动漫 = "119";
		break;
		case 22 :
			网络操作_动漫.发送网络请求("https://www.360kan.com/dongman/list?year=all&area=all&cat=120","get","txt","",5000);
			cat_动漫 = "120";
		break;
		case 23 :
			网络操作_动漫.发送网络请求("https://www.360kan.com/dongman/list?year=all&area=all&cat=121","get","txt","",5000);
			cat_动漫 = "121";
		break;
		case 24 :
			网络操作_动漫.发送网络请求("https://www.360kan.com/dongman/list?year=all&area=all&cat=122","get","txt","",5000);
			cat_动漫 = "122";
		break;
		case 25 :
			网络操作_动漫.发送网络请求("https://www.360kan.com/dongman/list?year=all&area=all&cat=123","get","txt","",5000);
			cat_动漫 = "123";
		break;
		case 26 :
			网络操作_动漫.发送网络请求("https://www.360kan.com/dongman/list?year=all&area=all&cat=124","get","txt","",5000);
			cat_动漫 = "124";
		break;
		case 27 :
			网络操作_动漫.发送网络请求("https://www.360kan.com/dongman/list?year=all&area=all&cat=125","get","txt","",5000);
			cat_动漫 = "125";
		break;
		case 28 :
			网络操作_动漫.发送网络请求("https://www.360kan.com/dongman/list?year=all&area=all&cat=126","get","txt","",5000);
			cat_动漫 = "126";
		break;
		case 29 :
			网络操作_动漫.发送网络请求("https://www.360kan.com/dongman/list?year=all&area=all&cat=127","get","txt","",5000);
			cat_动漫 = "127";
		break;
		case 30 :
			网络操作_动漫.发送网络请求("https://www.360kan.com/dongman/list?year=all&area=all&cat=128","get","txt","",5000);
			cat_动漫 = "128";
		break;
		case 31 :
			网络操作_动漫.发送网络请求("https://www.360kan.com/dongman/list?year=all&area=all&cat=129","get","txt","",5000);
			cat_动漫 = "129";
		break;
		case 32 :
			网络操作_动漫.发送网络请求("https://www.360kan.com/dongman/list?year=all&area=all&cat=130","get","txt","",5000);
			cat_动漫 = "130";
		break;
		case 33 :
			网络操作_动漫.发送网络请求("https://www.360kan.com/dongman/list?year=all&area=all&cat=131","get","txt","",5000);
			cat_动漫 = "131";
		break;
		case 34 :
			网络操作_动漫.发送网络请求("https://www.360kan.com/dongman/list?year=all&area=all&cat=132","get","txt","",5000);
			cat_动漫 = "132";
		break;
		case 35 :
			网络操作_动漫.发送网络请求("https://www.360kan.com/dongman/list?year=all&area=all&cat=133","get","txt","",5000);
			cat_动漫 = "133";
		break;
	}
}



function CYS悬浮文字导航_年份电视剧_项目被单击(项目索引){
	标题栏1.置标题("电视剧");
	读写设置.保存设置("播放分类","电视");
	switch(项目索引){
		case 0 :
			网络操作_电视.发送网络请求("https://www.360kan.com/dianshi/list","get","txt","",5000);
			cat_电视剧 = "all";
			year_电视剧  = "all";
		break;
		case 1 :
			网络操作_电视.发送网络请求("https://www.360kan.com/dianshi/list?cat=all&area=all&act=all&year=2018","get","txt","",5000);
			cat_电视剧 = "all";
			year_电视剧  = "2018";
		break;
		case 2 :
			网络操作_电视.发送网络请求("https://www.360kan.com/dianshi/list?cat=all&area=all&act=all&year=2017","get","txt","",5000);
			cat_电视剧 = "all";
			year_电视剧  = "2017";
		break;
		case 3 :
			网络操作_电视.发送网络请求("https://www.360kan.com/dianshi/list?cat=all&area=all&act=all&year=2016","get","txt","",5000);
			cat_电视剧 = "all";
			year_电视剧  = "2016";
		break;
		case 4 :
			网络操作_电视.发送网络请求("https://www.360kan.com/dianshi/list?cat=all&area=all&act=all&year=2015","get","txt","",5000);
			cat_电视剧 = "all";
			year_电视剧  = "2015";
		break;
		case 5 :
			网络操作_电视.发送网络请求("https://www.360kan.com/dianshi/list?cat=all&area=all&act=all&year=2014","get","txt","",5000);
			cat_电视剧 = "all";
			year_电视剧  = "2014";
		break;
		case 6 :
			网络操作_电视.发送网络请求("https://www.360kan.com/dianshi/list?cat=all&area=all&act=all&year=2013","get","txt","",5000);
			cat_电视剧 = "all";
			year_电视剧  = "2013";
		break;
		case 7 :
			网络操作_电视.发送网络请求("https://www.360kan.com/dianshi/list?cat=all&area=all&act=all&year=2012","get","txt","",5000);
			cat_电视剧 = "all";
			year_电视剧  = "2012";
		break;
		case 8 :
			网络操作_电视.发送网络请求("https://www.360kan.com/dianshi/list?cat=all&area=all&act=all&year=2011","get","txt","",5000);
			cat_电视剧 = "all";
			year_电视剧  = "2011";
		break;
		case 9 :
			网络操作_电视.发送网络请求("https://www.360kan.com/dianshi/list?cat=all&area=all&act=all&year=2010","get","txt","",5000);
			cat_电视剧 = "all";
			year_电视剧  = "2010";
		break;
		case 10 :
			网络操作_电视.发送网络请求("https://www.360kan.com/dianshi/list?cat=all&area=all&act=all&year=2009","get","txt","",5000);
			cat_电视剧 = "all";
			year_电视剧  = "2009";
		break;
		case 11 :
			网络操作_电视.发送网络请求("https://www.360kan.com/dianshi/list?cat=all&area=all&act=all&year=2008","get","txt","",5000);
			cat_电视剧 = "all";
			year_电视剧  = "2008";
		break;
		case 12 :
			网络操作_电视.发送网络请求("https://www.360kan.com/dianshi/list?cat=all&area=all&act=all&year=2007","get","txt","",5000);
			cat_电视剧 = "all";
			year_电视剧  = "2007";
		break;
		case 13 :
			网络操作_电视.发送网络请求("https://www.360kan.com/dianshi/list?cat=all&area=all&act=all&year=other","get","txt","",5000);
			cat_电视剧 = "all";
			year_电视剧  = "other";
		break;
	}
}

function CYS悬浮文字导航_年份电影_项目被单击(项目索引){
	标题栏1.置标题("电影");
	读写设置.保存设置("播放分类","电影");
	switch(项目索引){
		case 0 :
			网络操作_电影.发送网络请求("https://www.360kan.com/dianying/list","get","txt","",5000);
			cat_电影 = "all";
			year_电影  = "all";
		break;
		case 1 :
			网络操作_电影.发送网络请求("https://www.360kan.com/dianying/list?cat=all&area=all&act=all&year=2018","get","txt","",5000);
			cat_电影 = "all";
			year_电影  = "2018";
		break;
		case 2 :
			网络操作_电影.发送网络请求("https://www.360kan.com/dianying/list?cat=all&area=all&act=all&year=2017","get","txt","",5000);
			cat_电影 = "all";
			year_电影  = "2017";
		break;
		case 3 :
			网络操作_电影.发送网络请求("https://www.360kan.com/dianying/list?cat=all&area=all&act=all&year=2016","get","txt","",5000);
			cat_电影 = "all";
			year_电影  = "2016";
		break;
		case 4 :
			网络操作_电影.发送网络请求("https://www.360kan.com/dianying/list?cat=all&area=all&act=all&year=2015","get","txt","",5000);
			cat_电影 = "all";
			year_电影  = "2015";
		break;
		case 5 :
			网络操作_电影.发送网络请求("https://www.360kan.com/dianying/list?cat=all&area=all&act=all&year=2014","get","txt","",5000);
			cat_电影 = "all";
			year_电影  = "2014";
		break;
		case 6 :
			网络操作_电影.发送网络请求("https://www.360kan.com/dianying/list?cat=all&area=all&act=all&year=2013","get","txt","",5000);
			cat_电影 = "all";
			year_电影  = "2013";
		break;
		case 7 :
			网络操作_电影.发送网络请求("https://www.360kan.com/dianying/list?cat=all&area=all&act=all&year=2012","get","txt","",5000);
			cat_电影 = "all";
			year_电影  = "2012";
		break;
		case 8 :
			网络操作_电影.发送网络请求("https://www.360kan.com/dianying/list?cat=all&area=all&act=all&year=2011","get","txt","",5000);
			cat_电影 = "all";
			year_电影  = "2011";
		break;
		case 9 :
			网络操作_电影.发送网络请求("https://www.360kan.com/dianying/list?cat=all&area=all&act=all&year=2010","get","txt","",5000);
			cat_电影 = "all";
			year_电影  = "2010";
		break;
		case 10 :
			网络操作_电影.发送网络请求("https://www.360kan.com/dianying/list?cat=all&area=all&act=all&year=2009","get","txt","",5000);
			cat_电影 = "all";
			year_电影  = "2009";
		break;
		case 11 :
			网络操作_电影.发送网络请求("https://www.360kan.com/dianying/list?cat=all&area=all&act=all&year=2008","get","txt","",5000);
			cat_电影 = "all";
			year_电影  = "2008";
		break;
		case 12 :
			网络操作_电影.发送网络请求("https://www.360kan.com/dianying/list?cat=all&area=all&act=all&year=2007","get","txt","",5000);
			cat_电影 = "all";
			year_电影  = "2007";
		break;
		case 13 :
			网络操作_电影.发送网络请求("https://www.360kan.com/dianying/list?cat=all&area=all&act=all&year=other","get","txt","",5000);
			cat_电影 = "all";
			year_电影  = "other";
		break;
	}
}

function CYS悬浮文字导航_年份综艺_项目被单击(项目索引){
	标题栏1.置标题("综艺");
	读写设置.保存设置("播放分类","综艺");
	switch(项目索引){
		case 0 :
			网络操作_综艺.发送网络请求("https://www.360kan.com/zongyi/list","get","txt","",5000);
			cat_综艺 = "all";
			year_综艺  = "all";
		break;
		case 1 :
			网络操作_综艺.发送网络请求("https://www.360kan.com/zongyi/list?cat=all&area=all&act=徐熙娣","get","txt","",5000);
			cat_综艺 = "all";
			year_综艺  = "徐熙娣";
		break;
		case 2 :
			网络操作_综艺.发送网络请求("https://www.360kan.com/zongyi/list?cat=all&area=all&act=蔡康永","get","txt","",5000);
			cat_综艺 = "all";
			year_综艺  = "蔡康永";
		break;
		case 3 :
			网络操作_综艺.发送网络请求("https://www.360kan.com/zongyi/list?cat=all&area=all&act=陈鲁豫","get","txt","",5000);
			cat_综艺 = "all";
			year_综艺  = "陈鲁豫";
		break;
		case 4 :
			网络操作_综艺.发送网络请求("https://www.360kan.com/zongyi/list?cat=all&area=all&act=孟非","get","txt","",5000);
			cat_综艺 = "all";
			year_综艺  = "孟非";
		break;
		case 5 :
			网络操作_综艺.发送网络请求("https://www.360kan.com/zongyi/list?cat=all&area=all&act=乐嘉","get","txt","",5000);
			cat_综艺 = "all";
			year_综艺  = "乐嘉";
		break;
		case 6 :
			网络操作_综艺.发送网络请求("https://www.360kan.com/zongyi/list?cat=all&area=all&act=何炅","get","txt","",5000);
			cat_综艺 = "all";
			year_综艺  = "何炅";
		break;
		case 7 :
			网络操作_综艺.发送网络请求("https://www.360kan.com/zongyi/list?cat=all&area=all&act=谢娜","get","txt","",5000);
			cat_综艺 = "all";
			year_综艺  = "谢娜";
		break;
		case 8 :
			网络操作_综艺.发送网络请求("https://www.360kan.com/zongyi/list?cat=all&area=all&act=罗志祥","get","txt","",5000);
			cat_综艺 = "all";
			year_综艺  = "罗志祥";
		break;
		case 9 :
			网络操作_综艺.发送网络请求("https://www.360kan.com/zongyi/list?cat=all&area=all&act=陶晶莹","get","txt","",5000);
			cat_综艺 = "all";
			year_综艺  = "陶晶莹";
		break;
		case 10 :
			网络操作_综艺.发送网络请求("https://www.360kan.com/zongyi/list?cat=all&area=all&act=郭德纲","get","txt","",5000);
			cat_综艺 = "all";
			year_综艺  = "郭德纲";
		break;
		case 11 :
			网络操作_综艺.发送网络请求("https://www.360kan.com/zongyi/list?cat=all&area=all&act=周立波","get","txt","",5000);
			cat_综艺 = "all";
			year_综艺  = "周立波";
		break;
		case 12 :
			网络操作_综艺.发送网络请求("https://www.360kan.com/zongyi/list?cat=all&area=all&act=窦文涛","get","txt","",5000);
			cat_综艺 = "all";
			year_综艺  = "窦文涛";
		break;
		case 13 :
			网络操作_综艺.发送网络请求("https://www.360kan.com/zongyi/list?cat=all&area=all&act=汪涵","get","txt","",5000);
			cat_综艺 = "all";
			year_综艺  = "汪涵";
		break;
		case 14 :
			网络操作_综艺.发送网络请求("https://www.360kan.com/zongyi/list?cat=all&area=all&act=陈建州","get","txt","",5000);
			cat_综艺 = "all";
			year_综艺  = "陈建州";
		break;
		case 15 :
			网络操作_综艺.发送网络请求("https://www.360kan.com/zongyi/list?cat=all&area=all&act=王刚","get","txt","",5000);
			cat_综艺 = "all";
			year_综艺  = "王刚";
		break;
		case 16 :
			网络操作_综艺.发送网络请求("https://www.360kan.com/zongyi/list?cat=all&area=all&act=朱丹","get","txt","",5000);
			cat_综艺 = "all";
			year_综艺  = "朱丹";
		break;
	}
}

function CYS悬浮文字导航_年份动漫_项目被单击(项目索引){
	标题栏1.置标题("动漫");
	读写设置.保存设置("播放分类","动漫");
	switch(项目索引){
		case 0 :
			网络操作_动漫.发送网络请求("https://www.360kan.com/dongman/list","get","txt","",5000);
			cat_动漫 = "all";
			year_动漫  = "all";
		break;
		case 1 :
			网络操作_动漫.发送网络请求("https://www.360kan.com/dongman/list?cat=all&area=all&year=2018","get","txt","",5000);
			cat_动漫 = "all";
			year_动漫  = "2018";
		break;
		case 2 :
			网络操作_动漫.发送网络请求("https://www.360kan.com/dongman/list?cat=all&area=all&year=2017","get","txt","",5000);
			cat_动漫 = "all";
			year_动漫  = "2017";
		break;
		case 3 :
			网络操作_动漫.发送网络请求("https://www.360kan.com/dongman/list?cat=all&area=all&year=2016","get","txt","",5000);
			cat_动漫 = "all";
			year_动漫  = "2016";
		break;
		case 4 :
			网络操作_动漫.发送网络请求("https://www.360kan.com/dongman/list?cat=all&area=all&year=2015","get","txt","",5000);
			cat_动漫 = "all";
			year_动漫  = "2015";
		break;
		case 5 :
			网络操作_动漫.发送网络请求("https://www.360kan.com/dongman/list?cat=all&area=all&year=2014","get","txt","",5000);
			cat_动漫 = "all";
			year_动漫  = "2014";
		break;
		case 6 :
			网络操作_动漫.发送网络请求("https://www.360kan.com/dongman/list?cat=all&area=all&year=2013","get","txt","",5000);
			cat_动漫 = "all";
			year_动漫  = "2013";
		break;
		case 7 :
			网络操作_动漫.发送网络请求("https://www.360kan.com/dongman/list?cat=all&area=all&year=2012","get","txt","",5000);
			cat_动漫 = "all";
			year_动漫  = "2012";
		break;
		case 8 :
			网络操作_动漫.发送网络请求("https://www.360kan.com/dongman/list?cat=all&area=all&year=2011","get","txt","",5000);
			cat_动漫 = "all";
			year_动漫  = "2011";
		break;
		case 9 :
			网络操作_动漫.发送网络请求("https://www.360kan.com/dongman/list?cat=all&area=all&year=2010","get","txt","",5000);
			cat_动漫 = "all";
			year_动漫  = "2010";
		break;
		case 10 :
			网络操作_动漫.发送网络请求("https://www.360kan.com/dongman/list?cat=all&area=all&year=2009","get","txt","",5000);
			cat_动漫 = "all";
			year_动漫  = "2009";
		break;
		case 11 :
			网络操作_动漫.发送网络请求("https://www.360kan.com/dongman/list?cat=all&area=all&year=2008","get","txt","",5000);
			cat_动漫 = "all";
			year_动漫  = "2008";
		break;
		case 12 :
			网络操作_动漫.发送网络请求("https://www.360kan.com/dongman/list?cat=all&area=all&year=2007","get","txt","",5000);
			cat_动漫 = "all";
			year_动漫  = "2007";
		break;
		case 13 :
			网络操作_动漫.发送网络请求("https://www.360kan.com/dongman/list?cat=all&area=all&year=2006","get","txt","",5000);
			cat_动漫 = "all";
			year_动漫  = "2006";
		break;
		case 14 :
			网络操作_动漫.发送网络请求("https://www.360kan.com/dongman/list?cat=all&area=all&year=2005","get","txt","",5000);
			cat_动漫 = "all";
			year_动漫  = "2005";
		break;
		case 15 :
			网络操作_动漫.发送网络请求("https://www.360kan.com/dongman/list?cat=all&area=all&year=2004","get","txt","",5000);
			cat_动漫 = "all";
			year_动漫  = "2004";
		break;
		case 16 :
			网络操作_动漫.发送网络请求("https://www.360kan.com/dongman/list?cat=all&area=all&year=other","get","txt","",5000);
			cat_动漫 = "all";
			year_动漫  = "other";
		break;
	}
}



function CYS悬浮文字导航_地区电视剧_项目被单击(项目索引){
	标题栏1.置标题("电视剧");
	读写设置.保存设置("播放分类","电视");
	switch(项目索引){
		case 0 :
			网络操作_电视.发送网络请求("https://www.360kan.com/dianshi/list","get","txt","",5000);
			cat_电视剧 = "all";
			year_电视剧  = "all";
			area_电视剧 = "all";
		break;
		case 1 :
			网络操作_电视.发送网络请求("https://www.360kan.com/dianshi/list?cat=all&year=all&act=all&area=10","get","txt","",5000);
			cat_电视剧 = "all";
			year_电视剧  = "all";
			area_电视剧 = "10";
		break;
		case 2 :
			网络操作_电视.发送网络请求("https://www.360kan.com/dianshi/list?cat=all&year=all&act=all&area=11","get","txt","",5000);
			cat_电视剧 = "all";
			year_电视剧  = "all";
			area_电视剧 = "11";
		break;
		case 3 :
			网络操作_电视.发送网络请求("https://www.360kan.com/dianshi/list?cat=all&year=all&act=all&area=16","get","txt","",5000);
			cat_电视剧 = "all";
			year_电视剧  = "all";
			area_电视剧 = "16";
		break;
		case 4 :
			网络操作_电视.发送网络请求("https://www.360kan.com/dianshi/list?cat=all&year=all&act=all&area=12","get","txt","",5000);
			cat_电视剧 = "all";
			year_电视剧  = "all";
			area_电视剧 = "12";
		break;
		case 5 :
			网络操作_电视.发送网络请求("https://www.360kan.com/dianshi/list?cat=all&year=all&act=all&area=14","get","txt","",5000);
			cat_电视剧 = "all";
			year_电视剧  = "all";
			area_电视剧 = "14";
		break;
		case 6 :
			网络操作_电视.发送网络请求("https://www.360kan.com/dianshi/list?cat=all&year=all&act=all&area=15","get","txt","",5000);
			cat_电视剧 = "all";
			year_电视剧  = "all";
			area_电视剧 = "15";
		break;
		case 7 :
			网络操作_电视.发送网络请求("https://www.360kan.com/dianshi/list?cat=all&year=all&act=all&area=13","get","txt","",5000);
			cat_电视剧 = "all";
			year_电视剧  = "all";
			area_电视剧 = "13";
		break;
		case 8 :
			网络操作_电视.发送网络请求("https://www.360kan.com/dianshi/list?cat=all&year=all&act=all&area=17","get","txt","",5000);
			cat_电视剧 = "all";
			year_电视剧  = "all";
			area_电视剧 = "17";
		break;
		case 9 :
			网络操作_电视.发送网络请求("https://www.360kan.com/dianshi/list?cat=all&year=all&act=all&area=18","get","txt","",5000);
			cat_电视剧 = "all";
			year_电视剧  = "all";
			area_电视剧 = "18";

		break;
	}
}

function CYS悬浮文字导航_地区电影_项目被单击(项目索引){
	标题栏1.置标题("电影");
	读写设置.保存设置("播放分类","电影");
	switch(项目索引){
		case 0 :
			网络操作_电影.发送网络请求("https://www.360kan.com/dianshi/list","get","txt","",5000);
			cat_电影 = "all";
			year_电影  = "all";
			area_电影 = "all";
		break;
		case 1 :
			网络操作_电影.发送网络请求("https://www.360kan.com/dianying/list?cat=all&year=all&act=all&area=11","get","txt","",5000);
			cat_电影 = "all";
			year_电影  = "all";
			area_电影 = "11";
		break;
		case 2 :
			网络操作_电影.发送网络请求("https://www.360kan.com/dianying/list?cat=all&year=all&act=all&area=10","get","txt","",5000);
			cat_电影 = "all";
			year_电影  = "all";
			area_电影 = "10";
		break;
		case 3 :
			网络操作_电影.发送网络请求("https://www.360kan.com/dianying/list?cat=all&year=all&act=all&area=15","get","txt","",5000);
			cat_电影 = "all";
			year_电影  = "all";
			area_电影 = "15";
		break;
		case 4 :
			网络操作_电影.发送网络请求("https://www.360kan.com/dianying/list?cat=all&year=all&act=all&area=13","get","txt","",5000);
			cat_电影 = "all";
			year_电影  = "all";
			area_电影 = "13";
		break;
		case 5 :
			网络操作_电影.发送网络请求("https://www.360kan.com/dianying/list?cat=all&year=all&act=all&area=14","get","txt","",5000);
			cat_电影 = "all";
			year_电影  = "all";
			area_电影 = "14";
		break;
		case 6 :
			网络操作_电影.发送网络请求("https://www.360kan.com/dianying/list?cat=all&year=all&act=all&area=12","get","txt","",5000);
			cat_电影 = "all";
			year_电影  = "all";
			area_电影 = "12";
		break;
		case 7 :
			网络操作_电影.发送网络请求("https://www.360kan.com/dianying/list?cat=all&year=all&act=all&area=16","get","txt","",5000);
			cat_电影 = "all";
			year_电影  = "all";
			area_电影 = "16";
		break;
		case 8 :
			网络操作_电影.发送网络请求("https://www.360kan.com/dianying/list?cat=all&year=all&act=all&area=17","get","txt","",5000);
			cat_电影 = "all";
			year_电影  = "all";
			area_电影 = "17";
		break;
		case 9 :
			网络操作_电影.发送网络请求("https://www.360kan.com/dianying/list?cat=all&year=all&act=all&area=18","get","txt","",5000);
			cat_电影 = "all";
			year_电影  = "all";
			area_电影 = "18";
		break;
		case 10 :
			网络操作_电影.发送网络请求("https://www.360kan.com/dianying/list?cat=all&year=all&act=all&area=21","get","txt","",5000);
			cat_电影 = "all";
			year_电影  = "all";
			area_电影 = "21";
		break;
		case 11 :
			网络操作_电影.发送网络请求("https://www.360kan.com/dianying/list?cat=all&year=all&act=all&area=22","get","txt","",5000);
			cat_电影 = "all";
			year_电影  = "all";
			area_电影 = "22";
		break;
		case 12 :
			网络操作_电影.发送网络请求("https://www.360kan.com/dianying/list?cat=all&year=all&act=all&area=other","get","txt","",5000);
			cat_电影 = "all";
			year_电影  = "all";
			area_电影 = "other";

		break;
	}
}

function CYS悬浮文字导航_地区综艺_项目被单击(项目索引){
	标题栏1.置标题("综艺");
	读写设置.保存设置("播放分类","综艺");
	switch(项目索引){
		case 0 :
			网络操作_综艺.发送网络请求("https://www.360kan.com/zongyi/list","get","txt","",5000);
			cat_综艺 = "all";
			year_综艺  = "all";
			area_综艺 = "all";
		break;
		case 1 :
			网络操作_综艺.发送网络请求("https://www.360kan.com/zongyi/list?cat=all&act=all&area=10","get","txt","",5000);
			cat_综艺 = "all";
			year_综艺  = "all";
			area_综艺 = "10";
		break;
		case 2 :
			网络操作_综艺.发送网络请求("https://www.360kan.com/zongyi/list?cat=all&act=all&area=11","get","txt","",5000);
			cat_综艺 = "all";
			year_综艺  = "all";
			area_综艺 = "11";
		break;
		case 3 :
			网络操作_综艺.发送网络请求("https://www.360kan.com/zongyi/list?cat=all&act=all&area=12","get","txt","",5000);
			cat_综艺 = "all";
			year_综艺  = "all";
			area_综艺 = "12";
		break;
		case 4 :
			网络操作_综艺.发送网络请求("https://www.360kan.com/zongyi/list?cat=all&act=all&area=13","get","txt","",5000);
			cat_综艺 = "all";
			year_综艺  = "all";
			area_综艺 = "13";
		break;
		case 5 :
			网络操作_综艺.发送网络请求("https://www.360kan.com/zongyi/list?cat=all&act=all&area=14","get","txt","",5000);
			cat_综艺 = "all";
			year_综艺  = "all";
			area_综艺 = "14";
		break;
		case 6 :
			网络操作_综艺.发送网络请求("https://www.360kan.com/zongyi/list?cat=all&act=all&area=15","get","txt","",5000);
			cat_综艺 = "all";
			year_综艺  = "all";
			area_综艺 = "15";

		break;
	}
}

function CYS悬浮文字导航_地区动漫_项目被单击(项目索引){
	标题栏1.置标题("动漫");
	读写设置.保存设置("播放分类","动漫");
	switch(项目索引){
		case 0 :
			网络操作_动漫.发送网络请求("https://www.360kan.com/dongman/list","get","txt","",5000);
			cat_动漫 = "all";
			year_动漫  = "all";
			area_动漫 = "all";
		break;
		case 1 :
			网络操作_动漫.发送网络请求("https://www.360kan.com/dongman/list?cat=all&year=all&area=11","get","txt","",5000);
			cat_动漫 = "all";
			year_动漫  = "all";
			area_动漫 = "11";
		break;
		case 2 :
			网络操作_动漫.发送网络请求("https://www.360kan.com/dongman/list?cat=all&year=all&area=12","get","txt","",5000);
			cat_动漫 = "all";
			year_动漫  = "all";
			area_动漫 = "12";
		break;
		case 3 :
			网络操作_动漫.发送网络请求("https://www.360kan.com/dongman/list?cat=all&year=all&area=10","get","txt","",5000);
			cat_动漫 = "all";
			year_动漫  = "all";
			area_动漫 = "10";

		break;
	}
}

function 按钮组1_被单击(按钮索引){

	switch(按钮索引){
		case 3 :
			if(电视剧页数 == 30 ){
				仔仔弹出对话框1.提示("已经是最后一页了",8000);
			}else{
			    对话框1.显示等待框("正在加载影视内容请稍候....");
			    电视剧页数 = 电视剧页数 + 1;
			    网络操作_电视.发送网络请求(网页_电视剧 + cat_电视剧 + "&area=" + area_电视剧 + "&act=" + act_电视剧 +  "&year=" + year_电视剧 + "&pageno=" + 电视剧页数,"get","html","",5000);
			}

		break;
		case 2 :
			if(电视剧页数 == 1 ){
				仔仔弹出对话框1.提示("这已经是第一页了",8000);
			}else{
			    对话框1.显示等待框("正在加载影视内容请稍候....");
			    电视剧页数 = 电视剧页数 - 1;
			    网络操作_电视.发送网络请求(网页_电视剧 + cat_电视剧 + "&area=" + area_电视剧 + "&act=" + act_电视剧 +  "&year=" + year_电视剧 + "&pageno=" + 电视剧页数,"get","html","",5000);
			}
		break;
	}
}

function 按钮组2_被单击(按钮索引){

	switch(按钮索引){
		case 3 :
			if(电影页数 == 30 ){
				仔仔弹出对话框1.提示("已经是最后一页了",8000);
			}else{
			    对话框1.显示等待框("正在加载影视内容请稍候....");
			    电影页数 = 电影页数 + 1;
			    网络操作_电影.发送网络请求(网页_电影 + cat_电影 + "&area=" + area_电影 + "&act=" + act_电影 +  "&year=" + year_电影 + "&pageno=" + 电影页数,"get","html","",5000);
			}

		break;
		case 2 :
			if(电影页数 == 1 ){
				仔仔弹出对话框1.提示("这已经是第一页了",8000);
			}else{
			    对话框1.显示等待框("正在加载影视内容请稍候....");
			    电影页数 = 电影页数 - 1;
			    网络操作_电影.发送网络请求(网页_电影 + cat_电影 + "&area=" + area_电影 + "&act=" + act_电影 +  "&year=" + year_电影 + "&pageno=" + 电影页数,"get","html","",5000);
			}
		break;
	}
}

function 按钮组3_被单击(按钮索引){

	switch(按钮索引){
		case 3 :
			if(综艺页数 == 30 ){
				仔仔弹出对话框1.提示("已经是最后一页了",8000);
			}else{
			    对话框1.显示等待框("正在加载影视内容请稍候....");
			    综艺页数 = 综艺页数 + 1;
			    网络操作_综艺.发送网络请求(网页_综艺 + cat_综艺 + "&area=" + area_综艺 + "&act=" + act_综艺 +  "&year=" + year_综艺 + "&pageno=" + 综艺页数,"get","html","",5000);
			}

		break;
		case 2 :
			if(综艺页数 == 1 ){
				仔仔弹出对话框1.提示("这已经是第一页了",8000);
			}else{
			    对话框1.显示等待框("正在加载影视内容请稍候....");
			    综艺页数 = 综艺页数 - 1;
			    网络操作_综艺.发送网络请求(网页_综艺 + cat_综艺 + "&area=" + area_综艺 + "&act=" + act_综艺 +  "&year=" + year_综艺 + "&pageno=" + 综艺页数,"get","html","",5000);
			}
		break;
	}
}

function 按钮组4_被单击(按钮索引){

	switch(按钮索引){
		case 3 :
			if(动漫页数 == 30 ){
				仔仔弹出对话框1.提示("已经是最后一页了",8000);
			}else{
			    对话框1.显示等待框("正在加载影视内容请稍候....");
			    动漫页数 = 动漫页数 + 1;
			    网络操作_动漫.发送网络请求(网页_动漫 + cat_动漫 + "&area=" + area_动漫 + "&act=" + act_动漫 +  "&year=" + year_动漫 + "&pageno=" + 动漫页数,"get","html","",5000);
			}

		break;
		case 2 :
			if(动漫页数 == 1 ){
				仔仔弹出对话框1.提示("这已经是第一页了",8000);
			}else{
			    对话框1.显示等待框("正在加载影视内容请稍候....");
			    动漫页数 = 动漫页数 - 1;
			    网络操作_动漫.发送网络请求(网页_动漫 + cat_动漫 + "&area=" + area_动漫 + "&act=" + act_动漫 +  "&year=" + year_动漫 + "&pageno=" + 动漫页数,"get","html","",5000);
			}
		break;
	}
}


function 图片框1_被单击(){
	if(读写设置.读取设置("判断展开") == "已展开" ){
							面板_小分类电视.置可视(false);
							面板_小分类电影.置可视(false);
							面板_小分类综艺.置可视(false);
							面板_小分类动漫.置可视(false);

							面板_年份电视剧.置可视(false);
							面板_年份电影.置可视(false);
							面板_年份综艺.置可视(false);
							面板_年份动漫.置可视(false);

							面板_地区电视剧.置可视(false);
							面板_地区电影.置可视(false);
							面板_地区综艺.置可视(false);
							面板_地区动漫.置可视(false);

							按钮组1.置可视(false);
							按钮组2.置可视(false);
							按钮组3.置可视(false);
							按钮组4.置可视(false);

							读写设置.保存设置("判断展开","未展开");
		}else{

							面板_小分类电视.置可视(true);
							面板_小分类电影.置可视(false);
							面板_小分类综艺.置可视(false);
							面板_小分类动漫.置可视(false);

							面板_年份电视剧.置可视(true);
							面板_年份电影.置可视(false);
							面板_年份综艺.置可视(false);
							面板_年份动漫.置可视(false);

							面板_地区电视剧.置可视(true);
							面板_地区电影.置可视(false);
							面板_地区综艺.置可视(false);
							面板_地区动漫.置可视(false);

							按钮组1.置可视(true);
							按钮组2.置可视(false);
							按钮组3.置可视(false);
							按钮组4.置可视(false);

							网络操作_电视.发送网络请求("https://www.360kan.com/dianshi/list","get","txt","",5000);
							读写设置.保存设置("判断展开","已展开");

	}

}

function 搜索被点击(){
	窗口操作.切换窗口("./soso.html","");
}

function 分类视频_切换完毕(附加参数){
	窗口操作.预加载窗口("./bofangye.html");
}
